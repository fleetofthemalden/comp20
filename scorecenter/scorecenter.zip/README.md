Scorecenter
______________

Programmer: Dixon Minnick

Collaboration: Piazza

Correctly Implemented:
Webapp with the following APIs
/submit.json
/highscores.json
/
/usersearch

Hours Spent:
20-30?
No idea