
var express = require('express');
var app = express.createServer(express.logger());
app.use(express.bodyParser());
app.set('title', 'nodeapp');

var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://heroku_app14858084:j8ilkvadi9qo4tc643aih4e4iq@ds043497.mongolab.com:43497/heroku_app14858084';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
	db.createCollection('highscores', function(error,coll){});
});

app.get('/', function(request, response, next) {
  console.log(request);
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "X-Requested-With");
  response.sendfile('index.html');
});

app.get('/usersearch', function(request, response, next) {
  console.log(request);
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "X-Requested-With");
  response.sendfile('usersearch.html');
});

app.get('/highscores.json', function(request, response, next) {
  console.log(request);
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "X-Requested-With");
  
  var reqq = JSON.stringify(request.query);
  if(reqq != "{}"){
  	db.collection('highscores').find(request.query).limit(10).sort({score: -1}).toArray(function(err, items){
  		response.set('Content-Type', 'text/json');
  		response.send(items);
  	});
   }
   else{
   	db.collection('highscores').find(request.query).sort({score: -1}).toArray(function(err, items){
  		response.set('Content-Type', 'text/json');
  		response.send(items);
  	});
  }
  
});

app.post('/submit.json', function (request, response, next){
	console.log(request);
	response.header("Access-Control-Allow-Origin", "*");
  	response.header("Access-Control-Allow-Headers", "X-Requested-With");
  	
	db.collection('highscores', function(er, collection) {
			console.log(er);
			var req = request.body;
			req.score = parseInt(req.score);
			collection.insert(req);
		});
	response.set('Content-Type', 'text/json');
	response.send(200, {"status":"OK"});
});

var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});



