README for Assignment 5. Max Smiley
-----------------------------------

Correctly Implemented: All features described in assignment.

Collaborated with:
	- Pattra 

Time Spent: ~ 10.5 Hours