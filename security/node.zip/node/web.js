// Express and Mongo initialization
var express = require('express');
var app = express(express.logger());
app.use(express.bodyParser());
app.set('title', 'nodeapp');
var mongo = require('mongodb');
var mongoUri = "mongodb://heroku:99cents@dawson.mongohq.com:10012/app14059198";

//Permissions
app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

app.post('/submit.json', function (request, response){
	if(!request.body["game_title"] || !request.body["username"] || !request.body["score"]) {
	 	console.log("Data not formatted properly, ignoring.");
	}else {
	 	var date = new Date();
	    request.body["created_at"] = date.toString();
	   	console.log(request.body);
	 	mongo.Db.connect(mongoUri, function (err, db) {
	    db.collection('highscores', function(er, collection) {
	       collection.insert(request.body, {safe: true}, function(er,rs) {
	       });
	     });
	  });  
	}
});

app.get('/highscores.json', function (request, response) {
    response.set('Content-Type', 'text/json');
    console.log(request.query);
	mongo.Db.connect(mongoUri, function (err, db) {
		db.collection('highscores', function(er, collection) {
		    var cursor = collection.find(request.query);
		        cursor.limit(10);
		        cursor.sort( {"score" : -1});
	      		cursor.toArray(function(err, items) {   
		      		var intCount = items.length;
						 if(intCount > 0){
							var strJson = "";   
							//Convert to ints
							for(var i=0; i<intCount; i ++){
								items[i].score = parseInt(items[i].score);
							}  
							//Sort Descending Order
							function compare(a,b) {
							  if (a.score > b.score)
							     return -1;
							  if (a.score < b.score)
							   	 return 1;
							  return 0;
							}
							items.sort(compare);
							//Make JSON
							for(var i=0; i<intCount;){
								strJson += '{"game_title":"' + items[i].game_title + '"'
								        +  ', "username":"' + items[i].username + '"'
								        +  ', "score":"' + items[i].score + '"'
								        +  ', "created_at":"' + items[i].created_at + '"}';
								i=i+1;
								if(i<intCount){strJson+=',';}
							}
							strJson = '[' + strJson + "]"
							response.send(JSON.parse(strJson)); 	
						}else{
							response.send('[]'); 	
						}
	
        		});
    	    });
		});
});

app.get('/', function(request, res) {
	res.set('Content-Type', 'text/html');
	mongo.Db.connect(mongoUri, function (err, db) {
		db.collection('highscores', function(er, collection) {
		    var cursor = collection.find();
	      		cursor.toArray(function(err, items) {   
		      		var intCount = items.length;
		      		var page = "";    
		      		page = '<html><head><title>Hello Noder!</title></head><body>'
	                     + '<h1>HighScores!</h1>';
						 if(intCount > 0 && request.query != undefined){
							 var strJson ="";
							 page += '<table> ';
							 page += '<tr> <td> Game Title </td> '
							       + '<td> Username </td> ' 
							       + '<td> Score </td> '
							       + '<td> Created At </td> </tr>';
 							for(var i=0; i<intCount;){
							
							     page += '<tr>'
							          + '<td> ' + items[i].game_title + ' </td> ' 
							          + '<td> ' + items[i].username + ' </td> ' 
							          + '<td> ' + items[i].score + ' </td> ' 
							          + '<td> ' + items[i].created_at + ' </td> </tr>';
								i=i+1;
							}
							 page += '</table>';	
						}		
						res.send(page);
	
        		});
    	    });
		});
});

app.get('/usersearch', function(request, res) {
	res.set('Content-Type', 'text/html');
    console.log(request.query);
	mongo.Db.connect(mongoUri, function (err, db) {
		db.collection('highscores', function(er, collection) {
		    var cursor = collection.find(request.query);
	      		cursor.toArray(function(err, items) {   
		      		var intCount = items.length;
		      		var page = "";    
		      		page = '<html><head><title>Hello Noder!</title></head><body>'
	                     + '<h1>Search for highscores!</h1>'
	                     + '<form enctype="application/x-www-form-urlencoded" action="/usersearch" method="get">'
	                     + 'Username: <input id="input" type="text" name="username" value="" placeholder="Search..." />'
						 + '<input id="submit" type="submit" />'
						 + '</form>';
						 if(intCount > 0 && request.query["username"] != undefined){

						     page += '<h2> Results: </h2>';
							 page += '<table> ';
							 page += '<tr> <td> Game Title </td> '
							       + '<td> Username </td> ' 
							       + '<td> Score </td> '
							       + '<td> Created At </td> </tr>';
 							for(var i=0; i<intCount;){
							     page += '<tr>'
							          + '<td> ' + items[i].game_title + ' </td> ' 
							          + '<td> ' + items[i].username + ' </td> ' 
							          + '<td> ' + items[i].score + ' </td> ' 
							          + '<td> ' + items[i].created_at + ' </td> </tr>';
								i++;
							}
							 page += '</table></body></html>';
						}
						res.send(page);
	
        		});
    	    });
		});
});

app.get('/data.json', function(request, response) {
	response.set('Content-Type', 'text/json');
	response.send('{"status":"good"}');
});

app.get('/fool', function(request, response) {
	response.set('Content-Type', 'text/html');
	response.send(500, 'Something broke!');
});

app.listen(process.env.PORT || 3000);

